//
//  VerticalCell.h
//  SUNGiftList
//
//  Created by 孙 化育 on 13-4-20.
//  Copyright (c) 2013年 孙 化育. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VerticalCell : UITableViewCell{
    
}

@property (retain, nonatomic) IBOutlet UILabel *moneyLabel;
@property (retain, nonatomic) IBOutlet UILabel *nameLabel;


@end
