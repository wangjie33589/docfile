//
//  GiftListModel.h
//  SUNGiftList
//
//  Created by 孙 化育 on 13-4-14.
//  Copyright (c) 2013年 孙 化育. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GiftListModel : NSObject{
    
}

@property (nonatomic,copy)NSString *listTitle;
@property (nonatomic,copy)NSString *creatTime;
@property (nonatomic,copy)NSString *listNumber;

@end
