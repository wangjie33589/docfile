//
//  GiverModel.h
//  SUNGiftList
//
//  Created by 孙 化育 on 13-4-18.
//  Copyright (c) 2013年 孙 化育. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GiverModel : NSObject{
    
}

@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *money;
@property (nonatomic,copy)NSString *relatedList;
@property (nonatomic,copy)NSString *keyNum;

@end
